"use client"

import { useMemo, useState, useRef } from "react"
import Image from "next/image"
import { Search, Volume2, VolumeX, CheckCircle2 } from "lucide-react"
import { plaques, siteMeta, type Plaque } from "@/src/data/beerRoadData"
import { PlaqueModal } from "@/components/plaque-modal"

function searchText(p: Plaque) {
  const parts = [p.name, p.tagline, p.universe]
  if (p.content.intro) parts.push(...p.content.intro)
  if (p.content.albums) parts.push(...p.content.albums.map((a) => a.title))
  if (p.content.books) parts.push(...p.content.books.map((b) => b.title))
  if (p.content.highlights) parts.push(...p.content.highlights.map((h) => h.label))
  return parts.join(" ").toLowerCase()
}

export function BeerRoad() {
  const [active, setActive] = useState<Plaque | null>(null)
  const [query, setQuery] = useState("")
  const [isPlaying, setIsPlaying] = useState(false)
  const [visitedIds, setVisitedIds] = useState<Set<string>>(new Set())
  const audioRef = useRef<HTMLAudioElement | null>(null)

  const q = query.trim().toLowerCase()
  const matches = useMemo(() => {
    if (!q) return []
    return plaques.filter((p) => searchText(p).includes(q))
  }, [q])
  const matchIds = new Set(matches.map((m) => m.id))

  // Ouverture d'une plaque + enregistrement de la visite
  const handleOpenPlaque = (p: Plaque) => {
    setActive(p)
    setVisitedIds((prev) => new Set(prev).add(p.id))
  }

  // Gestion de la musique
  const toggleAudio = () => {
    if (!audioRef.current) return
    if (isPlaying) {
      audioRef.current.pause()
      setIsPlaying(false)
    } else {
      audioRef.current.play()
      setIsPlaying(true)
    }
  }

  const allVisited = visitedIds.size === plaques.length

  return (
    <main className="mx-auto flex h-screen w-full max-w-4xl flex-col overflow-hidden px-4 pb-3 pt-3 sm:px-6">
      <audio ref={audioRef} src="/ambiance.mp3" loop />

      {/* Header */}
      <header className="relative flex flex-col items-center gap-2 text-center">
        {/* Bouton Audio */}
        <button
          onClick={toggleAudio}
          title={isPlaying ? "Couper la musique" : "Écouter la compo de la Beer Road"}
          className="absolute right-0 top-0 flex items-center gap-2 rounded-full border border-border bg-card px-3 py-1.5 text-xs font-medium shadow-sm transition-all hover:bg-secondary focus-visible:ring-2 focus-visible:ring-primary"
        >
          {isPlaying ? (
            <>
              <Volume2 className="size-4 animate-pulse text-primary" />
              <span className="hidden sm:inline">Musique ON</span>
            </>
          ) : (
            <>
              <VolumeX className="size-4 text-muted-foreground" />
              <span className="hidden sm:inline">Activer le son 🎵</span>
            </>
          )}
        </button>

        <h1 className="font-serif text-2xl font-semibold tracking-tight sm:text-3xl">
          {siteMeta.title}{" "}
          <span aria-hidden="true">{siteMeta.emojiTitle}</span>
        </h1>
<p className="max-w-xl text-xs leading-normal text-muted-foreground sm:text-sm">
  Bienvenue sur le chemin de la Beer Road. Chaque plaque de ciment cache un petit univers : nos musiques, nos recettes, nos livres, nos histoires,...
  <span className="block mt-1.5 font-medium text-foreground">
    Cliquez sur une empreinte pour explorer.
  </span>
</p>

        {/* Global search */}
        <div className="relative w-full max-w-md">
          <label htmlFor="beer-road-search" className="sr-only">
            {siteMeta.searchPlaceholder}
          </label>
          <Search
            aria-hidden="true"
            className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground"
          />
          <input
            id="beer-road-search"
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={siteMeta.searchPlaceholder}
            className="w-full rounded-full border border-border bg-card py-1.5 pl-9 pr-4 text-xs shadow-sm outline-none transition-colors placeholder:text-muted-foreground focus-visible:border-primary focus-visible:ring-2 focus-visible:ring-ring/40 sm:py-2 sm:text-sm"
          />

          {q && (
            <div className="absolute left-0 right-0 top-full z-20 mt-1 overflow-hidden rounded-2xl border border-border bg-popover text-left shadow-xl">
              {matches.length === 0 ? (
                <p className="px-4 py-3 text-sm text-muted-foreground">Aucun résultat…</p>
              ) : (
                <ul>
                  {matches.map((m) => (
                    <li key={m.id}>
                      <button
                        onClick={() => {
                          handleOpenPlaque(m)
                          setQuery("")
                        }}
                        className="flex w-full items-center gap-3 px-4 py-2.5 text-left text-sm transition-colors hover:bg-secondary"
                      >
                        <span aria-hidden="true" className="text-lg">
                          {m.emoji}
                        </span>
                        <span>
                          <span className="block font-medium">{m.name}</span>
                          <span className="block text-xs text-muted-foreground">
                            {m.tagline}
                          </span>
                        </span>
                      </button>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          )}
        </div>
      </header>

      {/* Interactive photo */}
      <section
        aria-label="Le chemin de la Beer Road — cliquez sur une empreinte"
        className="relative my-2 flex flex-1 items-center justify-center overflow-hidden"
      >
        <div className="relative h-full aspect-[3/4] max-w-full overflow-hidden rounded-3xl border border-border shadow-xl">
          <Image
            src={siteMeta.heroImage || "/placeholder.svg"}
            alt="Le chemin de plaques de ciment..."
            fill
            priority
            sizes="(max-width: 768px) 100vw, 768px"
            className="select-none object-cover"
          />

          <div aria-hidden="true" className="pointer-events-none absolute inset-0 bg-foreground/5" />

          {plaques.map((p) => {
            const dimmed = q.length > 0 && !matchIds.has(p.id)
            const highlighted = q.length > 0 && matchIds.has(p.id)
            const isVisited = visitedIds.has(p.id)

            return (
              <button
                key={p.id}
                onClick={() => handleOpenPlaque(p)}
                aria-label={`${p.name} — ${p.tagline}`}
                className="group absolute rounded-2xl outline-none transition-all duration-300 focus-visible:ring-2 focus-visible:ring-primary"
                style={{
                  left: `${p.position.x}%`,
                  top: `${p.position.y}%`,
                  width: `${p.position.width}%`,
                  height: `${p.position.height}%`,
                  transform: `translate(-50%, -50%) rotate(${p.position.rotate ?? 0}deg)`,
                  opacity: dimmed ? 0.35 : 1,
                }}
              >
                {/* Contour avec indicateur si visité */}
                <span
                  aria-hidden="true"
                  className={`absolute inset-0 rounded-2xl border-2 transition-all duration-300 ${
                    highlighted
                      ? "border-accent shadow-[0_0_0_4px_var(--color-accent)] opacity-100"
                      : isVisited
                      ? "border-emerald-500/80 shadow-[0_0_12px_1px_rgba(16,185,129,0.5)] opacity-80"
                      : "border-accent/90 opacity-0 shadow-[0_0_18px_2px_var(--color-accent)] group-hover:opacity-100 group-focus-visible:opacity-100"
                  }`}
                />

                {/* Badge au survol */}
                <span
                  className={`pointer-events-none absolute left-1/2 top-0 z-10 flex -translate-x-1/2 -translate-y-[115%] items-center gap-1.5 whitespace-nowrap rounded-full bg-primary px-3 py-1 text-xs font-medium text-primary-foreground shadow-md transition-all duration-200 ${
                    highlighted
                      ? "opacity-100"
                      : "opacity-0 group-hover:opacity-100 group-focus-visible:opacity-100"
                  }`}
                >
                  <span aria-hidden="true">{p.emoji}</span>
                  {p.name}
                  {isVisited && <CheckCircle2 className="size-3.5 text-emerald-400" />}
                </span>
              </button>
            )
          })}
        </div>
      </section>

      {/* Compteur de progression interactif */}
      <footer className="flex flex-col items-center justify-center gap-1 text-center">
        <div className="flex items-center gap-2 rounded-full border border-border bg-card px-4 py-1 text-xs font-medium shadow-sm">
          <span>👣</span>
          <span>
            {allVisited ? (
              <span className="font-semibold text-emerald-600 dark:text-emerald-400">
                Bravo ! Toute la Beer Road explorée 🎉
              </span>
            ) : (
              <span>
                <strong className="text-primary">{visitedIds.size}</strong> sur{" "}
                <strong>{plaques.length}</strong> empreintes découvertes
              </span>
            )}
          </span>
        </div>
      </footer>

      {active && <PlaqueModal plaque={active} onClose={() => setActive(null)} />}
    </main>
  )
}