"use client"

import { useEffect, useRef } from "react"
import Image from "next/image"
import {
  X,
  Music,
  ExternalLink,
  FileText,
  PlayCircle,
  Newspaper,
  BookOpen,
  Beer,
} from "lucide-react"
import type { Plaque, PlaqueLink, Universe } from "@/src/data/beerRoadData"

const universeIcon: Record<Universe, typeof Beer> = {
  fondateur: Beer,
  musique: Music,
  cookiwiki: BookOpen,
  actus: Newspaper,
  livres: BookOpen,
  film: PlayCircle,
}

function LinkButton({ link }: { link: PlaqueLink }) {
  const icon =
    link.kind === "pdf" ? (
      <FileText className="size-4" />
    ) : link.kind === "video" ? (
      <PlayCircle className="size-4" />
    ) : link.kind === "external" ? (
      <ExternalLink className="size-4" />
    ) : (
      <Music className="size-4" />
    )

  return (
    <a
      href={link.url || undefined}
      target="_blank"
      rel="noopener noreferrer"
      className="inline-flex items-center gap-2 rounded-full border border-border bg-secondary px-4 py-2 text-sm font-medium text-secondary-foreground transition-colors hover:bg-primary hover:text-primary-foreground focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring"
    >
      {icon}
      {link.label}
    </a>
  )
}

export function PlaqueModal({
  plaque,
  onClose,
}: {
  plaque: Plaque
  onClose: () => void
}) {
  const closeRef = useRef<HTMLButtonElement>(null)

  useEffect(() => {
    closeRef.current?.focus()
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose()
    }
    document.addEventListener("keydown", onKey)
    document.body.style.overflow = "hidden"
    return () => {
      document.removeEventListener("keydown", onKey)
      document.body.style.overflow = ""
    }
  }, [onClose])

  const Icon = universeIcon[plaque.universe]
  const { content } = plaque

  return (
    <div
      className="fixed inset-0 z-50 flex items-end justify-center bg-foreground/50 p-0 backdrop-blur-sm sm:items-center sm:p-4"
      onClick={onClose}
      role="presentation"
    >
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="plaque-title"
        onClick={(e) => e.stopPropagation()}
        className="max-h-[90vh] w-full max-w-lg overflow-y-auto rounded-t-3xl border border-border bg-card text-card-foreground shadow-2xl sm:rounded-3xl"
      >
        {/* Header */}
        <div className="sticky top-0 z-10 flex items-start justify-between gap-4 border-b border-border bg-card/95 px-6 py-5 backdrop-blur">
          <div className="flex items-center gap-3">
            <span
              aria-hidden="true"
              className="flex size-11 shrink-0 items-center justify-center rounded-2xl bg-primary text-primary-foreground"
            >
              <Icon className="size-5" />
            </span>
            <div>
              <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                {plaque.tagline}
              </p>
              <h2 id="plaque-title" className="font-serif text-xl leading-tight text-pretty">
                {plaque.name}
              </h2>
            </div>
          </div>
          <button
            ref={closeRef}
            onClick={onClose}
            aria-label="Fermer"
            className="rounded-full p-2 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring"
          >
            <X className="size-5" />
          </button>
        </div>

        {/* Body */}
        <div className="flex flex-col gap-6 px-6 py-6">
          {content.intro?.map((p, i) => (
            <p key={i} className="leading-relaxed text-muted-foreground">
              {p}
            </p>
          ))}

          {/* Fondateur highlights */}
          {content.highlights && (
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              {content.highlights.map((h) => (
                <div
                  key={h.label}
                  className="rounded-2xl border border-border bg-secondary/60 p-4"
                >
                  <p className="font-medium">{h.label}</p>
                  <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
                    {h.description}
                  </p>
                </div>
              ))}
            </div>
          )}

          {/* Albums / musique */}
          {content.albums?.map((album) => (
            <div
              key={album.title}
              className="flex flex-col gap-4 rounded-2xl border border-border bg-secondary/50 p-4 sm:flex-row"
            >
              <div className="relative aspect-square w-full shrink-0 overflow-hidden rounded-xl bg-muted sm:w-28">
                <Image
                  src={album.cover || "/placeholder.svg?height=200&width=200&query=album cover"}
                  alt={`Pochette de ${album.title}`}
                  fill
                  sizes="112px"
                  className="object-cover"
                />
              </div>
              <div className="flex min-w-0 flex-col gap-3">
                <div>
                  <p className="font-serif text-lg leading-tight">{album.title}</p>
                  {album.subtitle && (
                    <p className="text-sm text-muted-foreground">{album.subtitle}</p>
                  )}
                </div>
                {album.audio && (
                  <audio controls preload="none" className="w-full">
                    <source src={album.audio} />
                    Votre navigateur ne supporte pas la lecture audio.
                  </audio>
                )}
                <div className="flex flex-wrap gap-2">
                  {album.links.map((l) => (
                    <LinkButton key={l.label} link={l} />
                  ))}
                </div>
              </div>
            </div>
          ))}

        {/* News feed */}
          {content.news && (
            <ol className="flex flex-col gap-4">
              {content.news.map((n, i) => (
                <li
                  key={i}
                  className="relative flex flex-col items-start rounded-2xl border border-border bg-secondary/50 p-4"
                >
                  <p className="text-xs font-medium uppercase tracking-wide text-accent-foreground">
                    {n.date}
                  </p>
                  <p className="mt-1 font-medium">{n.title}</p>
                  <p className="mt-1 text-sm leading-relaxed text-muted-foreground">{n.body}</p>
                  
                  {/* --- Bouton PDF dynamique --- */}
                  {n.pdf && (
                    <div className="mt-4">
                      <LinkButton link={{ label: "Lire le livret (PDF)", url: n.pdf, kind: "pdf" }} />
                    </div>
                  )}
                </li>
              ))}
            </ol>
          )}

          {/* Books */}
          {content.books?.map((book) => (
            <div
              key={book.title}
              className="flex flex-col gap-4 rounded-2xl border border-border bg-secondary/50 p-4 sm:flex-row"
            >
              <div className="relative aspect-[3/4] w-full shrink-0 overflow-hidden rounded-xl bg-muted sm:w-24">
                <Image
                  src={book.cover || "/placeholder.svg?height=240&width=180&query=children book cover"}
                  alt={`Couverture de ${book.title}`}
                  fill
                  sizes="96px"
                  className="object-cover"
                />
              </div>
              <div className="flex flex-col gap-3">
                <div>
                  <p className="font-serif text-lg leading-tight">{book.title}</p>
                  <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
                    {book.description}
                  </p>
                </div>
                {book.pdf ? (
                  <LinkButton link={{ label: "Lire le livre (PDF)", url: book.pdf, kind: "pdf" }} />
                ) : (
                  <p className="text-sm italic text-muted-foreground">Bientôt disponible…</p>
                )}
              </div>
            </div>
          ))}

          {/* Film / video */}
          {content.video && (
            <div className="flex flex-col gap-3">
              <div className="relative aspect-video w-full overflow-hidden rounded-2xl bg-muted">
                {content.video.embedUrl ? (
                  <iframe
                    src={content.video.embedUrl}
                    title={content.video.title}
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                    className="absolute inset-0 size-full"
                  />
                ) : (
                  <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 text-muted-foreground">
                    <PlayCircle className="size-10" />
                    <p className="text-sm italic">Le film arrive bientôt…</p>
                  </div>
                )}
              </div>
              {content.video.description && (
                <p className="text-sm leading-relaxed text-muted-foreground">
                  {content.video.description}
                </p>
              )}
            </div>
          )}

          {/* Simple links */}
          {content.links && (
            <div className="flex flex-wrap gap-3">
              {content.links.map((l) => (
                <LinkButton key={l.label} link={l} />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
